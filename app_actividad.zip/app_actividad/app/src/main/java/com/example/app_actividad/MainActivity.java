package com.example.app_actividad;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import com.android.support.*

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nombre = (EditText)findViewById(R.id.nombre);
        fecha = (EditText)findViewById(R.id.fecha);
        email = (EditText)findViewById(R.id.email);
        descripcion = (EditText)findViewById(R.id.descripcion);
        siguiente = (Button) findViewById(R.id.siguiente);

        siguiente.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClickViewer(View v){

            }
        })
    }
}
