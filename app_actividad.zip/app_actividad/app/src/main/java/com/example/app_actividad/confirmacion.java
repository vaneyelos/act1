package com.example.app_actividad;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class confirmacion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmacion);
    }
}